document.addEventListener('DOMContentLoaded', () => {
    const cookieBanner = document.querySelector('[data-cookie-banner]');
    if (cookieBanner) {
        const storageKey = 'geekhost_cookie_consent';
        const acceptButton = cookieBanner.querySelector('[data-cookie-accept]');
        const rejectButton = cookieBanner.querySelector('[data-cookie-reject]');
        const preferencesButton = cookieBanner.querySelector('[data-cookie-preferences]');
        const saveButton = cookieBanner.querySelector('[data-cookie-save]');
        const preferencesPanel = cookieBanner.querySelector('[data-cookie-panel]');
        const prefsCheckbox = cookieBanner.querySelector('[data-cookie-prefs]');

        const readConsent = () => {
            try {
                const raw = window.localStorage.getItem(storageKey);
                return raw ? JSON.parse(raw) : null;
            } catch {
                return null;
            }
        };

        const writeConsent = (payload) => {
            const value = JSON.stringify({
                ...payload,
                updatedAt: new Date().toISOString(),
            });
            try {
                window.localStorage.setItem(storageKey, value);
            } catch {
                // Ignore storage failures and still hide the banner for this session.
            }
            document.cookie = `geekhost_cookie_consent=${encodeURIComponent(payload.status)}; Max-Age=31536000; Path=/; SameSite=Lax`;
            cookieBanner.hidden = true;
        };

        const existingConsent = readConsent();
        if (!existingConsent || !existingConsent.status) {
            cookieBanner.hidden = false;
        } else if (prefsCheckbox && typeof existingConsent.preferences === 'boolean') {
            prefsCheckbox.checked = existingConsent.preferences;
        }

        acceptButton?.addEventListener('click', () => {
            writeConsent({ status: 'accepted', essential: true, preferences: true });
        });

        rejectButton?.addEventListener('click', () => {
            writeConsent({ status: 'rejected', essential: true, preferences: false });
        });

        preferencesButton?.addEventListener('click', () => {
            if (!preferencesPanel) return;
            preferencesPanel.hidden = !preferencesPanel.hidden;
        });

        saveButton?.addEventListener('click', () => {
            const preferencesEnabled = Boolean(prefsCheckbox?.checked);
            writeConsent({
                status: preferencesEnabled ? 'custom' : 'rejected',
                essential: true,
                preferences: preferencesEnabled,
            });
        });
    }

    const heroWord = document.querySelector('.hero-dynamic-word');
    if (heroWord) {
        const phrases = JSON.parse(heroWord.dataset.heroWords || '[]');
        const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

        if (phrases.length > 1 && !prefersReducedMotion) {
            let activeIndex = 0;
            const cycleWord = () => {
                const nextIndex = (activeIndex + 1) % phrases.length;
                heroWord.classList.remove('is-visible');
                heroWord.classList.add('is-exit');

                window.setTimeout(() => {
                    heroWord.textContent = phrases[nextIndex];
                    heroWord.classList.remove('is-exit');
                    heroWord.classList.add('is-visible');
                    activeIndex = nextIndex;
                }, 260);
            };

            heroWord.textContent = phrases[0];
            window.setInterval(cycleWord, 3000);
        } else if (phrases.length > 0) {
            heroWord.textContent = phrases[0];
            heroWord.classList.add('is-visible');
        }
    }

    const scrollTopButton = document.querySelector('[data-scroll-top]');

    if (scrollTopButton) {
        const updateScrollTopVisibility = () => {
            scrollTopButton.hidden = window.scrollY < 360;
        };

        updateScrollTopVisibility();
        window.addEventListener('scroll', updateScrollTopVisibility, { passive: true });
        scrollTopButton.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'auto' });
        });
    }

    const menuToggle = document.querySelector('.menu-toggle');
    const navigation = document.querySelector('.site-navigation');

    if (menuToggle && navigation) {
        menuToggle.addEventListener('click', () => {
            const isExpanded = menuToggle.getAttribute('aria-expanded') === 'true';
            menuToggle.setAttribute('aria-expanded', String(!isExpanded));
            navigation.classList.toggle('is-open', !isExpanded);
        });
    }

    const planCards = [...document.querySelectorAll('[data-plan-card]')];
    if (planCards.length > 0 && 'IntersectionObserver' in window) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.18, rootMargin: '0px 0px -8% 0px' });

        planCards.forEach((card, index) => {
            card.style.transitionDelay = `${index * 110}ms`;
            observer.observe(card);
        });
    } else {
        planCards.forEach((card) => card.classList.add('is-visible'));
    }

    const testimonialCarousel = document.querySelector('[data-testimonial-carousel]');
    if (testimonialCarousel) {
        const slides = [...testimonialCarousel.querySelectorAll('[data-testimonial-slide]')];
        const previousButton = testimonialCarousel.querySelector('[data-testimonial-prev]');
        const nextButton = testimonialCarousel.querySelector('[data-testimonial-next]');
        const dots = [...testimonialCarousel.querySelectorAll('[data-testimonial-dot]')];
        const status = testimonialCarousel.querySelector('[data-testimonial-status]');

        if (slides.length > 1 && previousButton && nextButton) {
            let activeIndex = Math.max(0, slides.findIndex((slide) => slide.classList.contains('is-active')));

            const showSlide = (index) => {
                activeIndex = (index + slides.length) % slides.length;
                slides.forEach((slide, slideIndex) => {
                    const isActive = slideIndex === activeIndex;
                    slide.classList.toggle('is-active', isActive);
                    slide.setAttribute('aria-hidden', String(!isActive));
                    slide.inert = !isActive;
                });
                dots.forEach((dot, dotIndex) => {
                    const isActive = dotIndex === activeIndex;
                    dot.classList.toggle('is-active', isActive);
                    dot.setAttribute('aria-pressed', String(isActive));
                });
                if (status) status.textContent = `Depoimento ${activeIndex + 1} de ${slides.length}`;
            };

            previousButton.addEventListener('click', () => showSlide(activeIndex - 1));
            nextButton.addEventListener('click', () => showSlide(activeIndex + 1));
            dots.forEach((dot) => {
                dot.addEventListener('click', () => showSlide(Number(dot.dataset.testimonialDot)));
            });
            testimonialCarousel.addEventListener('keydown', (event) => {
                if (event.key === 'ArrowLeft') {
                    event.preventDefault();
                    showSlide(activeIndex - 1);
                } else if (event.key === 'ArrowRight') {
                    event.preventDefault();
                    showSlide(activeIndex + 1);
                }
            });

            const viewport = testimonialCarousel.querySelector('[data-testimonial-viewport]');
            if (viewport) {
                let pointerId = null;
                let startX = 0;
                let startY = 0;
                viewport.addEventListener('pointerdown', (event) => {
                    if (event.pointerType === 'mouse') return;
                    pointerId = event.pointerId;
                    startX = event.clientX;
                    startY = event.clientY;
                });
                viewport.addEventListener('pointerup', (event) => {
                    if (pointerId !== event.pointerId) return;
                    const deltaX = event.clientX - startX;
                    const deltaY = event.clientY - startY;
                    pointerId = null;
                    if (Math.abs(deltaX) < 48 || Math.abs(deltaX) < Math.abs(deltaY)) return;
                    showSlide(deltaX < 0 ? activeIndex + 1 : activeIndex - 1);
                });
                viewport.addEventListener('pointercancel', () => {
                    pointerId = null;
                });
            }
            showSlide(activeIndex);
        }
    }

    const contactForm = document.querySelector('[data-contact-form]');
    if (contactForm) {
        contactForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const email = contactForm.dataset.contactEmail;
            const formData = new FormData(contactForm);
            const status = document.querySelector('[data-contact-status]');

            if (!email) {
                status.textContent = 'O canal de e-mail ainda não foi configurado.';
                return;
            }

            const subject = `[GeekHost] ${formData.get('subject')}`;
            const body = [
                `Nome: ${formData.get('name')}`,
                `E-mail para resposta: ${formData.get('email')}`,
                '',
                String(formData.get('message')),
            ].join('\n');
            window.location.href = `mailto:${encodeURIComponent(email)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
            status.textContent = 'Seu aplicativo de e-mail deve abrir com a mensagem pronta.';
        });
    }

    const generatorForm = document.querySelector('[data-generator-form]');
    if (generatorForm) {
        const countryCodeInput = document.querySelector('#country-code');
        const phoneInput = document.querySelector('#phone-number');
        const messageInput = document.querySelector('#whatsapp-message');
        const status = document.querySelector('[data-generator-status]');
        const qrContainer = document.querySelector('[data-qr-code]');
        const qrPlaceholder = document.querySelector('[data-qr-placeholder]');
        const qrError = document.querySelector('[data-qr-error]');
        const resultHint = document.querySelector('[data-result-hint]');
        const resultWrap = document.querySelector('[data-generated-link-wrap]');
        const generatedLink = document.querySelector('[data-generated-link]');
        const linkExpiryNote = document.querySelector('[data-link-expiry]');
        const openWhatsapp = document.querySelector('[data-open-whatsapp]');
        const copyButton = document.querySelector('[data-copy-link]');
        const downloadButton = document.querySelector('[data-download-qr]');
        const submitButton = generatorForm.querySelector('button[type="submit"]');
        const hostingDialog = document.querySelector('[data-hosting-dialog]');
        const dialogContinue = document.querySelector('[data-dialog-continue]');
        const dialogClose = document.querySelector('[data-dialog-close]');
        let pendingLink = '';

        const generateResult = async (linkData) => {
            submitButton.disabled = true;
            resultWrap.hidden = true;
            resultHint.hidden = false;
            linkExpiryNote.hidden = true;
            qrError.hidden = true;
            qrPlaceholder.hidden = false;
            qrContainer.hidden = true;
            status.textContent = 'Criando seu link temporário...';

            let result;
            try {
                const response = await fetch('criar-link.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(linkData),
                });
                result = await response.json();
                if (!response.ok || typeof result.url !== 'string' || !Number.isInteger(result.expiresAt)) {
                    throw new Error('Link temporário indisponível. Tente novamente.');
                }
            } catch {
                status.textContent = 'Não foi possível criar o link temporário. Tente novamente.';
                submitButton.disabled = false;
                return;
            }

            generatedLink.value = result.url;
            openWhatsapp.href = result.url;
            resultWrap.hidden = false;
            resultHint.hidden = true;
            status.textContent = 'Link criado. Confira e teste antes de divulgar.';
            const expiresAt = new Date(result.expiresAt * 1000);
            const formattedExpiry = new Intl.DateTimeFormat('pt-BR', { dateStyle: 'short', timeStyle: 'short' }).format(expiresAt);
            linkExpiryNote.textContent = `Válido até ${formattedExpiry}. Depois desse prazo, os acessos serão direcionados aos planos GeekHost.`;
            linkExpiryNote.hidden = false;

            if (typeof window.QRCode !== 'function') {
                qrPlaceholder.hidden = true;
                qrError.hidden = false;
                submitButton.disabled = false;
                return;
            }

            qrPlaceholder.hidden = true;
            qrContainer.hidden = false;
            qrContainer.replaceChildren();
            new window.QRCode(qrContainer, {
                text: result.url,
                width: 220,
                height: 220,
                colorDark: '#1a1e24',
                colorLight: '#ffffff',
                correctLevel: window.QRCode.CorrectLevel.H,
            });
            submitButton.disabled = false;
        };

        generatorForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const countryCode = countryCodeInput.value.replace(/\D/g, '');
            const phone = phoneInput.value.replace(/\D/g, '');
            const message = messageInput.value.trim();

            if (countryCode.length < 1 || countryCode.length > 3 || phone.length < 4 || `${countryCode}${phone}`.length > 15) {
                status.textContent = 'Informe um código de país e um número com DDD válidos.';
                phoneInput.focus();
                return;
            }

            const linkData = { number: `${countryCode}${phone}`, message };

            if (hostingDialog && typeof hostingDialog.showModal === 'function') {
                pendingLink = linkData;
                status.textContent = 'Escolha se deseja conhecer os planos ou continuar com o gerador gratuito.';
                hostingDialog.showModal();
                return;
            }

            generateResult(linkData);
        });

        if (hostingDialog && dialogContinue) {
            dialogContinue.addEventListener('click', () => {
                const linkData = pendingLink;
                pendingLink = '';
                hostingDialog.close();
                if (linkData) generateResult(linkData);
            });

            hostingDialog.addEventListener('close', () => {
                pendingLink = '';
            });
        }

        if (hostingDialog && dialogClose) {
            dialogClose.addEventListener('click', () => hostingDialog.close());
            hostingDialog.addEventListener('click', (event) => {
                if (event.target === hostingDialog) hostingDialog.close();
            });
        }

        copyButton.addEventListener('click', async () => {
            if (!generatedLink.value) return;
            try {
                await navigator.clipboard.writeText(generatedLink.value);
                copyButton.textContent = 'Copiado';
                status.textContent = 'Link copiado para a área de transferência.';
            } catch {
                generatedLink.select();
                status.textContent = 'Selecione e copie o link manualmente.';
            }
        });

        downloadButton.addEventListener('click', () => {
            const qrImage = qrContainer.querySelector('img');
            const qrCanvas = qrContainer.querySelector('canvas');
            const downloadUrl = qrCanvas ? qrCanvas.toDataURL('image/png') : qrImage?.src;

            if (!downloadUrl) {
                status.textContent = 'Gere um QR code antes de baixar.';
                return;
            }

            const downloadLink = document.createElement('a');
            downloadLink.href = downloadUrl;
            downloadLink.download = 'qr-code-whatsapp.png';
            downloadLink.click();
        });
    }

    const exitIntent = document.querySelector('[data-exit-intent]');
    if (exitIntent instanceof HTMLDialogElement) {
        const storageKey = 'geekhost_exit_intent_shown';
        const closeButtons = exitIntent.querySelectorAll('[data-exit-intent-close]');
        let armed = false;
        let shown = false;

        const alreadyShown = () => {
            try {
                return window.sessionStorage.getItem(storageKey) === '1';
            } catch {
                return shown;
            }
        };

        const markShown = () => {
            shown = true;
            try {
                window.sessionStorage.setItem(storageKey, '1');
            } catch {
                // Ignore storage failures for this session flag.
            }
        };

        const openExitIntent = () => {
            if (shown || alreadyShown() || exitIntent.open) return;
            markShown();
            if (typeof exitIntent.showModal === 'function') {
                exitIntent.showModal();
            } else {
                exitIntent.setAttribute('open', '');
            }
            document.body.classList.add('exit-intent-open');
        };

        const closeExitIntent = () => {
            if (typeof exitIntent.close === 'function') {
                exitIntent.close();
            } else {
                exitIntent.removeAttribute('open');
            }
            document.body.classList.remove('exit-intent-open');
        };

        closeButtons.forEach((button) => {
            button.addEventListener('click', closeExitIntent);
        });

        exitIntent.addEventListener('cancel', (event) => {
            event.preventDefault();
            closeExitIntent();
        });

        exitIntent.addEventListener('click', (event) => {
            if (event.target === exitIntent) closeExitIntent();
        });

        window.setTimeout(() => {
            armed = true;
        }, 1800);

        document.addEventListener('mouseout', (event) => {
            if (!armed || shown || alreadyShown()) return;
            const toElement = event.relatedTarget || event.toElement;
            if (toElement) return;
            if (event.clientY > 12) return;
            openExitIntent();
        });

        document.addEventListener('visibilitychange', () => {
            if (!armed || shown || alreadyShown()) return;
            if (document.visibilityState === 'hidden') {
                // Best-effort when the tab is backgrounded; modal shows on return if still needed.
                // Do not open while hidden; mark intent and open on visible if not dismissed.
            }
        });
    }
});